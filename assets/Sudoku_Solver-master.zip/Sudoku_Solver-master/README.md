# Sudoku_Solver
Sudoku solver is Java GUI based game
Which Solves sukoku puzzel (with help of Back Tracking algorithm)
