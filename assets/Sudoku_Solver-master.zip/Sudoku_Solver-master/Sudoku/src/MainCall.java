
public class MainCall {

	public static void main(String[] args) {
		
		MainFrame m1=new MainFrame();

	}

}
